import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { motion } from "motion/react";

const trainers = [
  {
    name: "Marco Schmidt",
    position: "Cheftrainer & Akademieleiter",
    experience: "UEFA Pro Lizenz, 15 Jahre Erfahrung",
    specialties: ["Taktik", "Jugendförderung", "Mentaltraining"],
    image: "https://images.unsplash.com/photo-1637559508411-e6d65573efff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGNvYWNoJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1ODI4OTIyN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    name: "Sarah Müller",
    position: "Jugendtrainerin",
    experience: "UEFA A Lizenz, Sportwissenschaft",
    specialties: ["Nachwuchsförderung", "Techniktraining", "Koordination"],
    image: "https://images.unsplash.com/photo-1594736797933-d0cb71d356ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx8ZmVtYWxlJTIwc29jY2VyJTIwY29hY2h8ZW58MXx8fHwxNzU4Mjg5MzM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    name: "Thomas Becker",
    position: "Torwarttrainer",
    experience: "Ex-Profi, UEFA B Lizenz",
    specialties: ["Torwartspezifisch", "Reflextraining", "Positionsspiel"],
    image: "https://images.unsplash.com/photo-1504279577054-acfeccf8fc52?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx8c29jY2VyJTIwZ29hbGtlZXBlciUyMGNvYWNofGVufDF8fHx8MTc1ODI4OTM0MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    name: "David Wagner",
    position: "Athletiktrainer",
    experience: "Sportwissenschaft M.A., DFB Elite",
    specialties: ["Kondition", "Kraft", "Verletzungsprävention"],
    image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx8Zml0bmVzcyUyMGNvYWNofGVufDF8fHx8MTc1ODI4OTM0M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  }
];

export function Trainers() {
  return (
    <section id="trainers" className="py-20 bg-gradient-to-br from-[#1E88E5]/5 via-white to-[#FF6B35]/5 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-16 left-16 w-28 h-28 bg-[#1E88E5] rounded-full"></div>
        <div className="absolute bottom-20 right-20 w-20 h-20 bg-[#FF6B35] rounded-full"></div>
        <div className="absolute top-1/2 right-1/4 w-16 h-16 bg-primary rounded-full"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="w-fit mx-auto bg-primary/10 text-primary">
            Unser Team
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold">
            Professionelle Trainer
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Unser erfahrenes Trainerteam bringt jahrelange Expertise und 
            Leidenschaft für den Fußball mit. Jeder Trainer ist speziell 
            qualifiziert für seine Bereiche.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {trainers.map((trainer, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
            >
              <Card className="group hover:shadow-xl transition-all duration-300 border-0 bg-white/90 backdrop-blur-sm h-full">
              <CardContent className="p-0">
                <div className="relative overflow-hidden rounded-t-lg">
                  <ImageWithFallback
                    src={trainer.image}
                    alt={trainer.name}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                
                <div className="p-6 space-y-4">
                  <div>
                    <h3 className="text-xl font-bold text-foreground">{trainer.name}</h3>
                    <p className="text-primary font-medium">{trainer.position}</p>
                    <p className="text-sm text-muted-foreground mt-1">{trainer.experience}</p>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {trainer.specialties.map((specialty, i) => (
                      <Badge key={i} variant="outline" className="text-xs border-primary/20 text-primary">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}