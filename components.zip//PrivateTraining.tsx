import { motion } from "motion/react";
import { Clock, Target, Zap, Brain, User, MapPin, Phone, Calendar } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

const trainingFocus = [
  {
    icon: Target,
    title: "Ballkontrolle",
    description: "Präzise Technik und sicheres Handling in jeder Situation",
    color: "text-[#1E88E5]",
    bg: "bg-[#1E88E5]/10"
  },
  {
    icon: Zap,
    title: "Athletik",
    description: "Explosivität, Schnelligkeit und körperliche Fitness",
    color: "text-[#43A047]",
    bg: "bg-[#43A047]/10"
  },
  {
    icon: Brain,
    title: "Spielintelligenz",
    description: "Taktisches Verständnis und schnelle Entscheidungsfindung",
    color: "text-[#FF6B35]",
    bg: "bg-[#FF6B35]/10"
  }
];

const sessionDetails = [
  {
    title: "Einzeltraining",
    duration: "60 Minuten",
    participants: "1 Spieler",
    price: "85€",
    features: ["Individueller Plan", "Videoanalyse", "Fortschrittsdokumentation"]
  },
  {
    title: "Kleingruppe",
    duration: "75 Minuten", 
    participants: "2-3 Spieler",
    price: "60€ / Person",
    features: ["Gruppendynamik", "Wettkampfcharakter", "Soziales Lernen"]
  },
  {
    title: "Team-Training",
    duration: "90 Minuten",
    participants: "4-8 Spieler", 
    price: "45€ / Person",
    features: ["Teamtaktik", "Spielformen", "Zusammenspiel"]
  }
];

const weeklySchedule = [
  { time: "16:00 - 17:00", type: "Einzeltraining", age: "U12-U14", spots: "2 Plätze" },
  { time: "17:15 - 18:30", type: "Kleingruppe", age: "U15-U17", spots: "1 Platz" },
  { time: "18:45 - 20:15", type: "Team-Training", age: "U18-U19", spots: "3 Plätze" }
];

export function PrivateTraining() {
  return (
    <section className="py-20 bg-gradient-to-br from-[#1E88E5]/10 via-white to-[#43A047]/10 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-16 left-16 w-24 h-24 bg-[#1E88E5] rounded-full"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-[#43A047] rounded-full"></div>
        <div className="absolute bottom-24 left-1/3 w-20 h-20 bg-[#FF6B35] rounded-full"></div>
        <div className="absolute bottom-16 right-16 w-12 h-12 bg-primary rounded-full"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-3 mb-6">
            <User className="w-8 h-8 text-primary" />
            <h2 className="text-4xl font-bold bg-gradient-to-r from-primary via-[#1E88E5] to-[#43A047] bg-clip-text text-transparent">
              Privates Fußball-Training
            </h2>
            <User className="w-8 h-8 text-primary" />
          </div>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg mb-6">
            Jeden Mittwoch bieten wir individuelles Training für maximalen Fortschritt. 
            Professionelle Einzelbetreuung und maßgeschneiderte Trainingspläne für alle Altersgruppen.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" />
              <span>Jeden Mittwoch</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" />
              <span>Sportpark Harburg</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-primary" />
              <span>Terminbuchung erforderlich</span>
            </div>
          </div>
        </motion.div>

        {/* Training Focus */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16"
        >
          {trainingFocus.map((focus, index) => (
            <motion.div
              key={focus.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.02, y: -5 }}
              className="group"
            >
              <Card className={`h-full border-0 shadow-lg hover:shadow-xl transition-all duration-300 ${focus.bg} backdrop-blur-sm`}>
                <CardContent className="p-6 text-center">
                  <div className={`w-16 h-16 ${focus.bg} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <focus.icon className={`w-8 h-8 ${focus.color}`} />
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-gray-800">{focus.title}</h3>
                  <p className="text-gray-600">{focus.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Training Options */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-3xl font-bold text-center mb-12 text-gray-800">Training-Optionen</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {sessionDetails.map((session, index) => (
              <motion.div
                key={session.title}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -8 }}
                className="group"
              >
                <Card className="h-full border-0 shadow-lg hover:shadow-2xl transition-all duration-300 bg-white/80 backdrop-blur-sm group-hover:bg-white">
                  <CardContent className="p-6">
                    <div className="text-center mb-6">
                      <h4 className="text-xl font-bold mb-2 text-gray-800">{session.title}</h4>
                      <div className="text-3xl font-bold text-primary mb-1">{session.price}</div>
                      <div className="text-sm text-gray-500">{session.participants}</div>
                    </div>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center gap-3 text-gray-600">
                        <Clock className="w-5 h-5 text-primary" />
                        <span>{session.duration}</span>
                      </div>
                      <div className="flex items-center gap-3 text-gray-600">
                        <User className="w-5 h-5 text-primary" />
                        <span>{session.participants}</span>
                      </div>
                    </div>

                    <div className="space-y-2 mb-6">
                      <h5 className="font-semibold text-gray-800">Inhalte:</h5>
                      <ul className="space-y-1">
                        {session.features.map((feature, idx) => (
                          <li key={idx} className="text-sm text-gray-600 flex items-center gap-2">
                            <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <Button className="w-full bg-gradient-to-r from-primary to-red-600 hover:from-red-600 hover:to-primary transition-all duration-300 group-hover:scale-105">
                      Termin buchen
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Weekly Schedule */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h3 className="text-3xl font-bold text-center mb-12 text-gray-800">Mittwoch Trainingszeiten</h3>
          <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm">
            <CardContent className="p-8">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-4 px-4 font-semibold text-gray-800">Zeit</th>
                      <th className="text-left py-4 px-4 font-semibold text-gray-800">Training-Art</th>
                      <th className="text-left py-4 px-4 font-semibold text-gray-800">Altersgruppe</th>
                      <th className="text-left py-4 px-4 font-semibold text-gray-800">Verfügbarkeit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {weeklySchedule.map((slot, index) => (
                      <motion.tr
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, delay: index * 0.1 }}
                        viewport={{ once: true }}
                        className="border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200"
                      >
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4 text-primary" />
                            <span className="font-semibold">{slot.time}</span>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <Badge className="bg-[#1E88E5]/10 text-[#1E88E5]">{slot.type}</Badge>
                        </td>
                        <td className="py-4 px-4 text-gray-600">{slot.age}</td>
                        <td className="py-4 px-4">
                          <Badge className="bg-[#43A047]/10 text-[#43A047]">{slot.spots}</Badge>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
          className="text-center bg-gradient-to-r from-primary via-[#1E88E5] to-[#43A047] rounded-2xl p-8 text-white shadow-2xl"
        >
          <h3 className="text-2xl font-bold mb-4">Starte dein persönliches Training!</h3>
          <p className="text-lg mb-6 opacity-90">
            Buche jetzt deinen ersten Termin und erlebe professionelles Einzeltraining.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-primary hover:bg-gray-100 font-semibold"
            >
              Termin vereinbaren
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-primary"
            >
              Beratung anfordern
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}