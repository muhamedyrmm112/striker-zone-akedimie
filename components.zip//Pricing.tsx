import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Check, Star, ArrowRight } from "lucide-react";

const pricingPlans = [
  {
    name: "Hobby",
    price: "45",
    period: "Monat",
    description: "Perfekt für Einsteiger und Freizeitspieler",
    features: [
      "1x Training pro Woche",
      "Grundlagentraining",
      "Vereinskleidung",
      "Saisonabschlussfeier"
    ],
    popular: false,
    cta: "Jetzt starten"
  },
  {
    name: "Leistung",
    price: "85",
    period: "Monat", 
    description: "Intensive Förderung für ambitionierte Spieler",
    features: [
      "2x Training pro Woche",
      "Taktikschulung",
      "Konditionstraining",
      "Turniere & Spiele",
      "Vereinskleidung",
      "Individualtraining (1x/Monat)"
    ],
    popular: true,
    cta: "Beliebteste Wahl"
  },
  {
    name: "Elite",
    price: "150",
    period: "Monat",
    description: "Profi-Vorbereitung für Nachwuchstalente",
    features: [
      "3x Training pro Woche",
      "Profi-Coaching",
      "Athletiktraining",
      "Ernährungsberatung",
      "Scout-Kontakte",
      "Komplette Ausrüstung",
      "Wöchentliche Einzelstunden"
    ],
    popular: false,
    cta: "Elite werden"
  }
];

const additionalServices = [
  {
    name: "Einzeltraining",
    price: "60",
    unit: "60 Min",
    description: "Individuelles Training mit Profi-Trainer"
  },
  {
    name: "Fußballcamp",
    price: "299",
    unit: "Woche",
    description: "Intensive Trainingswoche in den Ferien"
  },
  {
    name: "Torwart-Spezial",
    price: "70",
    unit: "Monat",
    description: "Zusätzliches Torwarttraining (1x/Woche)"
  }
];

export function Pricing() {
  return (
    <section id="pricing" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="w-fit mx-auto bg-primary/10 text-primary">
            Preise & Anmeldung
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold">
            Trainingsangebote
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Flexible Trainingspakete für jeden Spieler - vom Hobby-Kicker 
            bis zum Nachwuchstalent. Alle Preise verstehen sich monatlich.
          </p>
        </div>

        {/* Hauptpakete */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {pricingPlans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative group hover:shadow-2xl transition-all duration-300 ${
                plan.popular 
                  ? 'border-primary ring-2 ring-primary/20 scale-105' 
                  : 'border-border hover:border-primary/50'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground px-6 py-1">
                    <Star className="w-3 h-3 mr-1" />
                    Beliebt
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                <div className="space-y-2">
                  <div className="flex items-baseline justify-center space-x-1">
                    <span className="text-4xl font-bold text-primary">€{plan.price}</span>
                    <span className="text-muted-foreground">/{plan.period}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{plan.description}</p>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <ul className="space-y-3">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center space-x-3">
                      <Check className="h-4 w-4 text-primary flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className={`w-full group ${
                    plan.popular 
                      ? 'bg-primary hover:bg-primary/90' 
                      : ''
                  }`}
                  variant={plan.popular ? "default" : "outline"}
                >
                  {plan.cta}
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Zusatzleistungen */}
        <div className="space-y-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-2">Zusatzleistungen</h3>
            <p className="text-muted-foreground">
              Ergänze dein Training mit unseren speziellen Angeboten
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            {additionalServices.map((service, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6 text-center space-y-4">
                  <div>
                    <h4 className="font-bold text-lg">{service.name}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{service.description}</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-baseline justify-center space-x-1">
                      <span className="text-2xl font-bold text-primary">€{service.price}</span>
                      <span className="text-muted-foreground">/{service.unit}</span>
                    </div>
                    <Button variant="outline" size="sm" className="w-full">
                      Buchen
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Bereich */}
        <div className="text-center mt-16 p-8 bg-accent rounded-2xl">
          <h3 className="text-2xl font-bold mb-4">
            Kostenloses Probetraining vereinbaren
          </h3>
          <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
            Überzeugen Sie sich selbst von der Qualität unseres Trainings. 
            Das erste Training ist für alle neuen Spieler kostenlos!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="group">
              Probetraining buchen
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button variant="outline" size="lg">
              Beratungsgespräch
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}