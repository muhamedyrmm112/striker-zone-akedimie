import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Star, Quote } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const testimonials = [
  {
    name: "Lisa Weber",
    role: "Mutter von Leon (12 Jahre)",
    content: "Die FC Elite Akademie hat Leon nicht nur fußballerisch, sondern auch persönlich enorm weiterentwickelt. Die Trainer sind sehr professionell und gehen individuell auf jedes Kind ein.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx8cG9ydHJhaXQlMjB3b21hbiUyMHNtaWxpbmd8ZW58MXx8fHwxNzU4Mjg5NDMyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    name: "Michael Klein",
    role: "Vater von Emma (10 Jahre)",  
    content: "Fantastische Atmosphäre und tolle Trainer! Emma ist seit einem Jahr dabei und hat riesige Fortschritte gemacht. Besonders das Mädchen-Training ist sehr gut strukturiert.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx8cG9ydHJhaXQlMjBtYW4lMjBzbWlsaW5nfGVufDF8fHx8MTc1ODI4OTQzNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    name: "Julia Schmidt",
    role: "Mutter von Tim (14 Jahre)",
    content: "Tim trainiert seit 3 Jahren in der Akademie und wurde bereits von mehreren Vereinen gescoutet. Die professionelle Betreuung und das hochwertige Training zahlen sich aus!",
    rating: 5,
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx8cG9ydHJhaXQlMjB3b21hbiUyMGJ1c2luZXNzfGVufDF8fHx8MTc1ODI4OTQzNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  }
];

const achievements = [
  {
    number: "50+",
    title: "Vereinswechsel",
    description: "Spieler in höhere Ligen vermittelt"
  },
  {
    number: "300+",
    title: "Aktive Spieler",
    description: "Trainieren regelmäßig in unserer Akademie"
  },
  {
    number: "95%",
    title: "Zufriedenheit",
    description: "Der Eltern empfehlen uns weiter"
  },
  {
    number: "10+",
    title: "Jahre Erfahrung",
    description: "In der professionellen Nachwuchsförderung"
  }
];

export function Testimonials() {
  return (
    <section className="py-20 bg-primary text-primary-foreground">
      <div className="container mx-auto px-4">
        {/* Erfolge */}
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="w-fit mx-auto bg-white/10 text-white border-white/20">
            Unsere Erfolge
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold">
            Zahlen, die überzeugen
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {achievements.map((achievement, index) => (
            <div key={index} className="text-center space-y-2">
              <div className="text-4xl md:text-5xl font-bold text-white">
                {achievement.number}
              </div>
              <div className="text-xl font-medium text-white/90">
                {achievement.title}
              </div>
              <div className="text-white/70">
                {achievement.description}
              </div>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold">
            Was Eltern sagen
          </h2>
          <p className="text-white/80 text-lg max-w-2xl mx-auto">
            Die Zufriedenheit unserer Spieler und Eltern ist unser bester Beweis 
            für die Qualität unserer Arbeit.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white/10 border-white/20 backdrop-blur-sm">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <Quote className="h-8 w-8 text-white/40" />
                  <div className="flex space-x-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </div>
                
                <p className="text-white/90 leading-relaxed">
                  "{testimonial.content}"
                </p>
                
                <div className="flex items-center space-x-3 pt-4 border-t border-white/20">
                  <ImageWithFallback
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-medium text-white">{testimonial.name}</div>
                    <div className="text-sm text-white/70">{testimonial.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}