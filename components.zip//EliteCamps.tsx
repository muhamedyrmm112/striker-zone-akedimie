import { motion } from "motion/react";
import { Calendar, MapPin, Users, Star, Clock } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

const camps = [
  {
    id: 1,
    title: "Winter-Camp Hamburg",
    date: "15.-17. Februar 2025",
    location: "Sportpark Harburg",
    type: "Feld",
    participants: "U12-U18",
    price: "189€",
    features: ["Profi-Trainer", "3 Tage intensiv", "Zertifikat"]
  },
  {
    id: 2,
    title: "Frühjahrs-Camp Bremen",
    date: "12.-14. April 2025",
    location: "Werder Bremen Campus",
    type: "Exklusiv",
    participants: "U14-U19",
    price: "249€",
    features: ["Ex-Bundesliga Profi", "Taktik-Schulung", "Video-Analyse"]
  },
  {
    id: 3,
    title: "Sommer-Camp Lübeck",
    date: "18.-20. Juli 2025",
    location: "Holstein Kiel Academy",
    type: "Feld",
    participants: "U10-U16",
    price: "199€",
    features: ["Torwart-Training", "Kondition", "Teambuilding"]
  },
  {
    id: 4,
    title: "Herbst-Camp Hamburg",
    date: "26.-28. September 2025",
    location: "Millerntor-Stadion",
    type: "Halle",
    participants: "U13-U18",
    price: "229€",
    features: ["St. Pauli Profis", "Stadion-Tour", "Autogramme"]
  },
  {
    id: 5,
    title: "Winter-Elite Hamburg",
    date: "13.-15. Dezember 2025",
    location: "HSV Nachwuchszentrum",
    type: "Exklusiv",
    participants: "U15-U19",
    price: "299€",
    features: ["HSV Jugendtrainer", "Leistungsdiagnostik", "Talentsichtung"]
  },
  {
    id: 6,
    title: "Neujahrs-Camp 2026",
    date: "3.-5. Januar 2026",
    location: "FC St. Pauli Campus",
    type: "Halle",
    participants: "U11-U17",
    price: "179€",
    features: ["Neujahrs-Special", "Indoor-Technik", "Futsal-Training"]
  }
];

const getTypeColor = (type: string) => {
  switch (type) {
    case "Exklusiv":
      return "bg-gradient-to-r from-[#F7931E] to-[#FF6B35] text-white";
    case "Halle":
      return "bg-gradient-to-r from-[#1E88E5] to-[#DC3545] text-white";
    case "Feld":
      return "bg-gradient-to-r from-[#43A047] to-[#F7931E] text-white";
    default:
      return "bg-gray-500 text-white";
  }
};

export function EliteCamps() {
  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-20 h-20 bg-primary rounded-full"></div>
        <div className="absolute top-40 right-20 w-16 h-16 bg-[#1E88E5] rounded-full"></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-[#FF6B35] rounded-full"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Star className="w-8 h-8 text-primary" />
            <h2 className="text-4xl font-bold bg-gradient-to-r from-primary to-[#FF6B35] bg-clip-text text-transparent">
              Elite Camps 2025/2026
            </h2>
            <Star className="w-8 h-8 text-primary" />
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Intensive Trainingscamps mit Profi-Trainern und Ex-Bundesliga Spielern. 
            Verbessere deine Technik, Taktik und Kondition in professioneller Atmosphäre.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {camps.map((camp, index) => (
            <motion.div
              key={camp.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
              className="group"
            >
              <Card className="h-full border-0 shadow-lg hover:shadow-2xl transition-all duration-300 bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <Badge className={`${getTypeColor(camp.type)} px-3 py-1`}>
                      {camp.type}
                    </Badge>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">{camp.price}</div>
                      <div className="text-sm text-gray-500">pro Person</div>
                    </div>
                  </div>

                  <h3 className="text-xl font-bold mb-3 text-gray-800">{camp.title}</h3>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-3 text-gray-600">
                      <Calendar className="w-5 h-5 text-primary" />
                      <span>{camp.date}</span>
                    </div>
                    <div className="flex items-center gap-3 text-gray-600">
                      <MapPin className="w-5 h-5 text-primary" />
                      <span>{camp.location}</span>
                    </div>
                    <div className="flex items-center gap-3 text-gray-600">
                      <Users className="w-5 h-5 text-primary" />
                      <span>{camp.participants}</span>
                    </div>
                  </div>

                  <div className="space-y-2 mb-6">
                    <h4 className="font-semibold text-gray-800 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-primary" />
                      Highlights:
                    </h4>
                    <ul className="space-y-1">
                      {camp.features.map((feature, idx) => (
                        <li key={idx} className="text-sm text-gray-600 flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button 
                    className="w-full bg-gradient-to-r from-primary to-red-600 hover:from-red-600 hover:to-primary transition-all duration-300 group-hover:scale-105"
                  >
                    Jetzt anmelden
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <p className="text-gray-600 mb-6 text-lg">
            Frühe Anmeldung bis zum 31. Januar 2025 und spare 20€!
          </p>
          <Button size="lg" className="bg-gradient-to-r from-[#43A047] to-[#1E88E5] hover:from-[#1E88E5] hover:to-[#43A047]">
            Alle Camps ansehen
          </Button>
        </motion.div>
      </div>
    </section>
  );
}