import { motion } from "motion/react";
import { Trophy, Users, Calendar, MapPin, Target, Star, Medal } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

const tournamentStats = [
  { icon: Users, label: "Teams", value: "16", color: "text-[#1E88E5]" },
  { icon: Calendar, label: "Spiele", value: "6", color: "text-[#43A047]" },
  { icon: Target, label: "Modus", value: "Heim/Auswärts", color: "text-[#FF6B35]" },
  { icon: Medal, label: "Saison", value: "2025", color: "text-primary" }
];

const highlights = [
  {
    title: "Profi-Bedingungen",
    description: "Spiele auf echten Vereinsplätzen mit professioneller Ausstattung",
    icon: Star
  },
  {
    title: "Großer Pokal",
    description: "Der Sieger erhält einen beeindruckenden Wanderpokal und Medaillen",
    icon: Trophy
  },
  {
    title: "Fair Play",
    description: "Lizenzierte Schiedsrichter sorgen für faire und spannende Spiele",
    icon: Target
  }
];

export function ConferenceLeague() {
  return (
    <section className="py-20 bg-gradient-to-br from-primary/5 via-[#1E88E5]/10 to-[#FF6B35]/10 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 right-10 w-32 h-32 bg-primary rounded-full animate-pulse"></div>
        <div className="absolute bottom-20 left-10 w-24 h-24 bg-[#1E88E5] rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/3 w-16 h-16 bg-[#FF6B35] rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0.8, rotate: -10 }}
            whileInView={{ scale: 1, rotate: 0 }}
            transition={{ duration: 0.8, type: "spring" }}
            viewport={{ once: true }}
            className="flex items-center justify-center mb-6"
          >
            <Trophy className="w-16 h-16 text-[#F7931E] drop-shadow-lg" />
          </motion.div>
          
          <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary via-[#1E88E5] to-[#FF6B35] bg-clip-text text-transparent">
            Conference League of Hamburg
          </h2>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg leading-relaxed">
            Das prestigeträchtigste Nachwuchsturnier Hamburgs! 16 Teams kämpfen in einer 
            Liga um den großen Pokal. Professionelle Organisation, faire Spiele und 
            unvergessliche Fußball-Momente warten auf euch.
          </p>
        </motion.div>

        {/* Tournament Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16"
        >
          {tournamentStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.05 }}
              className="text-center"
            >
              <Card className="p-6 border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white/80 backdrop-blur-sm">
                <stat.icon className={`w-12 h-12 mx-auto mb-4 ${stat.color}`} />
                <div className="text-3xl font-bold text-gray-800 mb-2">{stat.value}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Tournament Format */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <Card className="border-0 shadow-xl bg-gradient-to-r from-white to-gray-50 overflow-hidden">
            <CardContent className="p-8">
              <div className="flex flex-col lg:flex-row items-center gap-8">
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-4 text-gray-800">Turnier-Format</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-primary mb-2 flex items-center gap-2">
                        <Calendar className="w-5 h-5" />
                        Spielplan
                      </h4>
                      <p className="text-gray-600">
                        Jedes Team spielt 6 Partien im Heim- und Auswärtsmodus. 
                        Spiele finden an Wochenenden statt.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-primary mb-2 flex items-center gap-2">
                        <MapPin className="w-5 h-5" />
                        Spielorte
                      </h4>
                      <p className="text-gray-600">
                        Auf den besten Plätzen Hamburgs: FC St. Pauli, HSV 
                        Nachwuchszentrum und weitere Vereinsplätze.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="lg:flex-shrink-0">
                  <motion.div
                    animate={{ rotate: [0, 5, -5, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                    className="bg-gradient-to-br from-[#F7931E] to-[#FF6B35] p-8 rounded-full shadow-2xl"
                  >
                    <Trophy className="w-24 h-24 text-white" />
                  </motion.div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Highlights */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12"
        >
          {highlights.map((highlight, index) => (
            <motion.div
              key={highlight.title}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.02 }}
            >
              <Card className="h-full border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white/90 backdrop-blur-sm">
                <CardContent className="p-6 text-center">
                  <highlight.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h4 className="font-bold mb-3 text-gray-800">{highlight.title}</h4>
                  <p className="text-gray-600">{highlight.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
          className="text-center bg-gradient-to-r from-primary to-red-600 rounded-2xl p-8 text-white shadow-2xl"
        >
          <h3 className="text-2xl font-bold mb-4">Seid dabei bei Hamburgs größtem Nachwuchsturnier!</h3>
          <p className="text-lg mb-6 opacity-90">
            Anmeldung bis zum 15. März 2025. Begrenzte Plätze verfügbar!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-primary hover:bg-gray-100 font-semibold"
            >
              Team anmelden
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-primary"
            >
              Mehr Infos
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}