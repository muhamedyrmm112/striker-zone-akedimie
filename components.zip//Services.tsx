import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { 
  Users, 
  Trophy, 
  Target, 
  Shield, 
  Heart, 
  Zap,
  ArrowRight,
  Clock,
  Calendar,
  MapPin
} from "lucide-react";
import { AnimatedSection } from "./AnimatedSection";
import { motion } from 'motion/react';

const programs = [
  {
    icon: Users,
    title: "Nachwuchstraining",
    subtitle: "6-18 Jahre",
    description: "Altersgerechtes Training für Kinder und Jugendliche mit professionellen Trainern und modernen Methoden.",
    features: ["U8 bis U19 Teams", "Techniktraining", "Taktikschulung", "Konditionstraining"],
    highlight: false
  },
  {
    icon: Trophy,
    title: "Leistungszentrum",
    subtitle: "Elite-Förderung",
    description: "Intensive Förderung für talentierte Spieler mit dem Ziel der Profikarriere und Vereinsvermittlung.",
    features: ["Talentsichtung", "Individuelles Training", "Vereinsvermittlung", "Profi-Scouts"],
    highlight: true
  },
  {
    icon: Target,
    title: "Torwarttraining",
    subtitle: "Spezialisiert",
    description: "Spezialisiertes Training für angehende Torhüter mit ehemaligen Profis und modernster Ausstattung.",
    features: ["Reaktionstraining", "Positionsspiel", "Flankenabwehr", "Elfmetertraining"],
    highlight: false
  },
  {
    icon: Shield,
    title: "Fußballcamps",
    subtitle: "Ferien-Intensiv",
    description: "Intensive Trainingswochen in den Ferien mit Übernachtung, Vollverpflegung und 24h Betreuung.",
    features: ["Sommercamp", "Herbstcamp", "Vollverpflegung", "24h Betreuung"],
    highlight: false
  },
  {
    icon: Heart,
    title: "Mädchenfußball",
    subtitle: "Girls Power",
    description: "Spezielles Programm zur Förderung des Frauenfußballs mit weiblichen Trainern und zielgerichteter Ausbildung.",
    features: ["Girls Only", "Weibliche Trainer", "Selbstvertrauen", "Teamgeist"],
    highlight: false
  },
  {
    icon: Zap,
    title: "Athletiktraining",
    subtitle: "Fitness & Kraft",
    description: "Moderne Trainingsmethoden zur Verbesserung von Kraft, Schnelligkeit, Ausdauer und Verletzungsprävention.",
    features: ["Krafttraining", "Schnelligkeit", "Koordination", "Verletzungsprävention"],
    highlight: false
  }
];

const scheduleInfo = [
  {
    icon: Clock,
    title: "Trainingszeiten",
    description: "Mo-Fr: 15:00-20:00 Uhr\nSa-So: 9:00-17:00 Uhr"
  },
  {
    icon: Calendar,
    title: "Ganzjährig",
    description: "Training auch in den\nSchulferien"
  },
  {
    icon: MapPin,
    title: "5 Trainingsplätze",
    description: "Moderne Anlagen mit\nOptimalem Equipment"
  }
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-gradient-to-br from-gray-50/50 via-white to-[#1E88E5]/5 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-32 right-16 w-40 h-40 bg-primary rounded-full blur-sm"></div>
        <div className="absolute bottom-40 left-20 w-24 h-24 bg-[#FF6B35] rounded-full blur-sm"></div>
        <div className="absolute top-1/2 left-1/2 w-32 h-32 bg-[#43A047] rounded-full blur-sm"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <AnimatedSection className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="w-fit mx-auto bg-primary/10 text-primary">
            Unsere Programme
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold">
            Professionelle Fußballausbildung
          </h2>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto">
            Von der Grundausbildung bis zur Profiförderung bieten wir 
            maßgeschneiderte Trainingsprogramme für jeden Entwicklungsstand 
            und jede Altersgruppe.
          </p>
        </AnimatedSection>

        {/* Training Info */}
        <AnimatedSection delay={0.2} className="grid md:grid-cols-3 gap-6 mb-16">
          {scheduleInfo.map((info, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <Card className="text-center border-0 bg-white/70 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 h-full">
                <CardContent className="p-6">
                  <motion.div 
                    className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    <info.icon className="h-6 w-6 text-primary" />
                  </motion.div>
                  <h4 className="font-bold mb-2">{info.title}</h4>
                  <p className="text-muted-foreground text-sm whitespace-pre-line">{info.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </AnimatedSection>

        {/* Programs Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {programs.map((program, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10, scale: program.highlight ? 1 : 1.03 }}
            >
              <Card 
                className={`group hover:shadow-2xl transition-all duration-500 border-0 h-full ${
                  program.highlight 
                    ? 'bg-gradient-to-br from-primary to-red-600 text-primary-foreground ring-2 ring-primary/20 scale-105 shadow-xl' 
                    : 'bg-white/80 backdrop-blur-sm hover:bg-white hover:border-primary/50'
                }`}
              >
              {program.highlight && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-white text-primary px-4 py-1">
                    Beliebt
                  </Badge>
                </div>
              )}
              
              <CardHeader className="relative">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-4 ${
                  program.highlight ? 'bg-white/10' : 'bg-primary/10'
                }`}>
                  <program.icon className={`h-8 w-8 ${
                    program.highlight ? 'text-white' : 'text-primary'
                  }`} />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{program.title}</CardTitle>
                    <Badge variant="outline" className={`text-xs ${
                      program.highlight 
                        ? 'border-white/20 text-white' 
                        : 'border-primary/20 text-primary'
                    }`}>
                      {program.subtitle}
                    </Badge>
                  </div>
                  <p className={`text-sm leading-relaxed ${
                    program.highlight ? 'text-white/80' : 'text-muted-foreground'
                  }`}>
                    {program.description}
                  </p>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <ul className="space-y-2">
                  {program.features.map((feature, i) => (
                    <li key={i} className="flex items-center space-x-2 text-sm">
                      <div className={`w-4 h-4 rounded-full flex items-center justify-center ${
                        program.highlight ? 'bg-white/10' : 'bg-primary/10'
                      }`}>
                        <div className={`w-2 h-2 rounded-full ${
                          program.highlight ? 'bg-white' : 'bg-primary'
                        }`} />
                      </div>
                      <span className={program.highlight ? 'text-white/90' : 'text-foreground'}>
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
                
                <div className="pt-4 border-t border-border/20">
                  <Button 
                    className={`w-full group ${
                      program.highlight 
                        ? 'bg-white text-primary hover:bg-white/90' 
                        : 'bg-primary hover:bg-primary/90'
                    }`}
                  >
                    Jetzt anfragen
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </div>
              </CardContent>
            </Card>
            </motion.div>
          ))}
        </div>

        <div className="text-center">
          <div className="inline-flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="bg-gradient-to-r from-primary to-red-600 hover:from-red-600 hover:to-primary px-8 py-6 rounded-full font-medium shadow-lg hover:shadow-xl transition-all duration-300">
              Alle Programme entdecken
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button variant="outline" size="lg" className="px-8 py-6 rounded-full font-medium border-2 border-primary/20 hover:border-primary hover:bg-primary/5 backdrop-blur-sm transition-all duration-300">
              Beratungstermin buchen
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}