import { useState } from "react";
import { Button } from "./ui/button";
import { Menu, X } from "lucide-react";
import logo from "figma:asset/35868fe9554c974f91f6411b4e196f76e1775fcc.png";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-md shadow-sm border-b border-white/20">
      <div className="container mx-auto px-4">
        <div className="flex h-20 items-center justify-between">
          <div className="flex items-center space-x-3">
            <img 
              src={logo} 
              alt="Striker Zone Academy Logo" 
              className="h-14 w-auto"
            />
            <div className="hidden sm:block">
              <h1 className="text-xl font-display text-foreground">Striker Zone</h1>
              <p className="text-sm text-primary font-body font-medium">Academy</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <a href="#home" className="text-foreground hover:text-primary transition-colors font-medium">
              Home
            </a>
            <a href="#about" className="text-foreground hover:text-primary transition-colors font-medium">
              Über uns
            </a>
            <a href="#services" className="text-foreground hover:text-primary transition-colors font-medium">
              Programme
            </a>
            <a href="#trainers" className="text-foreground hover:text-primary transition-colors font-medium">
              Trainer
            </a>
            <a href="#contact" className="text-foreground hover:text-primary transition-colors font-medium">
              Kontakt
            </a>
          </nav>

          <div className="hidden lg:flex items-center space-x-4">
            <Button variant="outline" className="btn-secondary-sports rounded-full">
              Probetraining ansehen
            </Button>
            <Button className="btn-primary-sports rounded-full">
              Jetzt anmelden
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 rounded-full hover:bg-accent"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="lg:hidden py-6 border-t bg-white/95 backdrop-blur-md">
            <nav className="flex flex-col space-y-4">
              <a 
                href="#home" 
                className="block py-3 text-foreground hover:text-primary transition-colors font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Home
              </a>
              <a 
                href="#about" 
                className="block py-3 text-foreground hover:text-primary transition-colors font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Über uns
              </a>
              <a 
                href="#services" 
                className="block py-3 text-foreground hover:text-primary transition-colors font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Programme
              </a>
              <a 
                href="#trainers" 
                className="block py-3 text-foreground hover:text-primary transition-colors font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Trainer
              </a>
              <a 
                href="#contact" 
                className="block py-3 text-foreground hover:text-primary transition-colors font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Kontakt
              </a>
              <div className="flex flex-col space-y-3 pt-4">
                <Button variant="outline" className="w-full rounded-full font-medium border-primary text-primary hover:bg-primary hover:text-white">
                  Probetraining ansehen
                </Button>
                <Button className="w-full rounded-full font-medium bg-primary hover:bg-primary/90">
                  Jetzt anmelden
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}