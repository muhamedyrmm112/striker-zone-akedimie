import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { CheckCircle, Heart, Target, Users, Trophy } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { AnimatedSection } from "./AnimatedSection";
import { motion } from 'motion/react';

const values = [
  {
    icon: Heart,
    title: "Leidenschaft",
    description: "Fußball ist unsere Leidenschaft - diese Begeisterung übertragen wir auf jeden Spieler."
  },
  {
    icon: Target,
    title: "Exzellenz",
    description: "Wir streben nach höchster Qualität in Training, Betreuung und Entwicklung."
  },
  {
    icon: Users,
    title: "Teamgeist",
    description: "Zusammenhalt und gegenseitiger Respekt sind die Basis unseres Erfolgs."
  },
  {
    icon: Trophy,
    title: "Erfolg",
    description: "Sportliche und persönliche Erfolge unserer Spieler sind unser Antrieb."
  }
];

export function About() {
  return (
    <section id="about" className="py-24 bg-gradient-to-br from-white via-gray-50/50 to-white relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-32 h-32 bg-primary rounded-full"></div>
        <div className="absolute bottom-32 right-20 w-24 h-24 bg-[#FF6B35] rounded-full"></div>
        <div className="absolute top-1/2 right-1/3 w-16 h-16 bg-[#1E88E5] rounded-full"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <AnimatedSection direction="left" className="space-y-8">
            <div className="space-y-6">
              <Badge variant="secondary" className="w-fit bg-primary/10 text-primary">
                Über uns
              </Badge>
              <h2 className="text-4xl md:text-5xl font-heading leading-tight">
                Unsere Mission: 
                <span className="block sports-gradient bg-clip-text text-transparent">Talente fördern</span>
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Die Striker Zone Academy steht für professionelle Nachwuchsförderung 
                im Fußball. Mit über 10 Jahren Erfahrung und einem Team aus 
                lizenzierten Trainern entwickeln wir die Fußballstars von morgen.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Unser ganzheitlicher Ansatz verbindet sportliche Exzellenz mit 
                charakterlicher Entwicklung und bereitet unsere Spieler optimal 
                auf ihre Fußball-Laufbahn vor.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium">Professionelle Trainer mit UEFA-Lizenz</h4>
                  <p className="text-muted-foreground text-sm mt-1">Alle unsere Trainer verfügen über höchste Qualifikationen</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium">Moderne Trainingsmethoden & Ausstattung</h4>
                  <p className="text-muted-foreground text-sm mt-1">Neueste Erkenntnisse aus Sportwissenschaft und Trainingslehre</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium">Individuelle Förderung jedes Spielers</h4>
                  <p className="text-muted-foreground text-sm mt-1">Persönliche Entwicklungspläne für optimale Fortschritte</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium">Ganzheitliche Entwicklung</h4>
                  <p className="text-muted-foreground text-sm mt-1">Sport, Charakter und mentale Stärke im Fokus</p>
                </div>
              </div>
            </div>
          </AnimatedSection>

          {/* Image */}
          <AnimatedSection direction="right" className="relative">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1705593813682-033ee2991df6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBmaWVsZCUyMHN0YWRpdW18ZW58MXx8fHwxNzU4MjAxNTc3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Modernes Fußballstadion und Trainingsplätze"
              className="rounded-3xl shadow-2xl w-full h-auto"
            />
            <div className="absolute -bottom-8 -left-8 bg-gradient-to-br from-primary to-red-600 text-primary-foreground p-6 rounded-2xl shadow-2xl border border-white/20">
              <div className="text-center">
                <div className="text-3xl font-bold">5</div>
                <div className="text-sm opacity-90">Trainingsplätze</div>
              </div>
            </div>
          </AnimatedSection>
        </div>

        {/* Values Section */}
        <AnimatedSection delay={0.2} className="mt-24">
          <div className="text-center space-y-4 mb-16">
            <h3 className="text-3xl md:text-4xl font-heading">Unsere Werte</h3>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Diese Grundsätze leiten uns in allem was wir tun und prägen 
              die Ausbildung in unserer Akademie.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <Card className="group hover:shadow-xl transition-all duration-500 border-0 bg-white/60 backdrop-blur-sm hover:bg-white/80">
                  <CardContent className="p-8 text-center space-y-4">
                    <motion.div 
                      className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto group-hover:bg-primary/20 transition-colors"
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ duration: 0.3 }}
                    >
                      <value.icon className="h-8 w-8 text-primary" />
                    </motion.div>
                    <h4 className="text-xl font-bold">{value.title}</h4>
                    <p className="text-muted-foreground">{value.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}