import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock,
  Send,
  MessageCircle
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Contact() {
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="w-fit mx-auto bg-primary/10 text-primary">
            Kontakt
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold">
            Werden Sie Teil unserer
            <span className="block text-primary">Fußball-Familie</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Interessiert an unserem Training? Kontaktieren Sie uns für 
            ein kostenloses Probetraining oder weitere Informationen. 
            Wir freuen uns auf Sie!
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-12 items-start">
          {/* Contact Info */}
          <div className="lg:col-span-2 space-y-8">
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <Mail className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">E-Mail</h3>
                  <p className="text-muted-foreground">info@striker-zone-academy.de</p>
                  <p className="text-sm text-muted-foreground mt-1">Antwort innerhalb von 24h</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <Phone className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Telefon</h3>
                  <p className="text-muted-foreground">+49 (0) 123 456 789</p>
                  <p className="text-sm text-muted-foreground mt-1">Mo-Fr: 9:00-18:00 Uhr</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <MessageCircle className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">WhatsApp</h3>
                  <p className="text-muted-foreground">+49 (0) 123 456 789</p>
                  <p className="text-sm text-muted-foreground mt-1">Schnelle Antworten täglich</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Trainingszentrum</h3>
                  <p className="text-muted-foreground">
                    Striker Zone Trainingszentrum<br />
                    Stadionstraße 45<br />
                    80331 München
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Trainingszeiten</h3>
                  <p className="text-muted-foreground">
                    Mo-Fr: 15:00 - 20:00 Uhr<br />
                    Sa-So: 9:00 - 17:00 Uhr
                  </p>
                </div>
              </div>
            </div>

            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1574772135913-d519461c3996?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGNvYWNoJTIwdHJhaW5pbmd8ZW58MXx8fHwxNzU4Mjg4NjAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Fußballtrainer mit jungen Spielern"
                className="rounded-2xl shadow-xl w-full h-64 object-cover"
              />
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-3">
            <Card className="shadow-xl border-0">
              <CardHeader className="text-center pb-6">
                <CardTitle className="text-2xl">Nachricht senden</CardTitle>
                <p className="text-muted-foreground">
                  Füllen Sie das Formular aus und wir melden uns schnellstmöglich bei Ihnen
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="font-medium">Name *</label>
                    <Input id="name" placeholder="Ihr Name" className="h-12" />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="font-medium">E-Mail *</label>
                    <Input id="email" type="email" placeholder="ihre@email.de" className="h-12" />
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="phone" className="font-medium">Telefon</label>
                    <Input id="phone" placeholder="Ihre Telefonnummer" className="h-12" />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="child-age" className="font-medium">Alter des Kindes</label>
                    <Input id="child-age" placeholder="z.B. 12 Jahre" className="h-12" />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="program" className="font-medium">Interessantes Programm</label>
                  <Input id="program" placeholder="z.B. Nachwuchstraining, Torwarttraining..." className="h-12" />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="message" className="font-medium">Nachricht *</label>
                  <Textarea 
                    id="message" 
                    placeholder="Erzählen Sie uns von Ihrem Kind, Ihren Wünschen und Fragen..."
                    className="min-h-32"
                  />
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button className="flex-1 h-12 bg-primary hover:bg-primary/90 group rounded-full font-medium">
                    Nachricht senden
                    <Send className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                  <Button variant="outline" className="flex-1 h-12 rounded-full font-medium">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    WhatsApp
                  </Button>
                </div>
                
                <p className="text-xs text-muted-foreground text-center">
                  * Pflichtfelder. Ihre Daten werden vertraulich behandelt und nicht an Dritte weitergegeben.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Google Maps Placeholder */}
        <div className="mt-16">
          <div className="bg-muted/50 rounded-2xl p-8 text-center">
            <h3 className="text-xl font-bold mb-2">Unser Trainingszentrum</h3>
            <p className="text-muted-foreground mb-4">
              Striker Zone Trainingszentrum, Stadionstraße 45, 80331 München
            </p>
            <div className="bg-muted rounded-xl h-64 flex items-center justify-center">
              <div className="text-center space-y-2">
                <MapPin className="h-12 w-12 text-primary mx-auto" />
                <p className="text-muted-foreground">
                  Interaktive Karte wird hier geladen<br />
                  (Google Maps Integration)
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}