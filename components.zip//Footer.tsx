import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Facebook, Instagram, Youtube, Twitter } from "lucide-react";
import { motion } from "motion/react";

export function Footer() {
  return (
    <footer className="bg-gradient-to-br from-primary via-red-600 to-red-700 text-primary-foreground relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-40 h-40 bg-white rounded-full blur-2xl"></div>
        <div className="absolute bottom-32 right-16 w-32 h-32 bg-[#FF6B35] rounded-full blur-2xl"></div>
        <div className="absolute top-1/2 right-1/4 w-24 h-24 bg-white rounded-full blur-xl"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        {/* Newsletter Section */}
        <motion.div 
          className="py-16 border-b border-white/10"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-center space-y-6">
            <h3 className="text-3xl font-bold">Bleiben Sie informiert</h3>
            <p className="text-white/80 max-w-lg mx-auto">
              Erhalten Sie aktuelle News, Trainingstipps und Informationen 
              zu unseren Camps und Events direkt in Ihr Postfach.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input 
                placeholder="Ihre E-Mail-Adresse" 
                className="flex-1 h-12 bg-white/10 border-white/20 text-white placeholder:text-white/60"
              />
              <Button className="bg-white text-primary hover:bg-white/90 px-8 h-12 font-medium shadow-lg hover:shadow-xl transition-all duration-300">
                Anmelden
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Main Footer Content */}
        <motion.div 
          className="py-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
            <div className="space-y-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-2xl text-primary">⚽</div>
                <div>
                  <h3 className="text-xl font-bold">Striker Zone Academy</h3>
                  <p className="text-sm text-white/70">Den Schritt nach vorne wagen</p>
                </div>
              </div>
              <p className="text-white/80 leading-relaxed">
                Die Striker Zone Academy - Ihre Fußball-Akademie für professionelle 
                Nachwuchsförderung und ganzheitliche Entwicklung junger Talente seit über 10 Jahren.
              </p>
              <div className="flex space-x-4">
                <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
                  <Button size="icon" variant="ghost" className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 transition-all duration-300">
                    <Facebook className="h-4 w-4" />
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
                  <Button size="icon" variant="ghost" className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 transition-all duration-300">
                    <Instagram className="h-4 w-4" />
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
                  <Button size="icon" variant="ghost" className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 transition-all duration-300">
                    <Youtube className="h-4 w-4" />
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
                  <Button size="icon" variant="ghost" className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 transition-all duration-300">
                    <Twitter className="h-4 w-4" />
                  </Button>
                </motion.div>
              </div>
            </div>

            <div className="space-y-6">
              <h4 className="text-lg font-bold">Programme</h4>
              <div className="space-y-3">
                <div><a href="#services" className="text-white/80 hover:text-white transition-colors">Nachwuchstraining</a></div>
                <div><a href="#services" className="text-white/80 hover:text-white transition-colors">Leistungszentrum</a></div>
                <div><a href="#services" className="text-white/80 hover:text-white transition-colors">Torwarttraining</a></div>
                <div><a href="#services" className="text-white/80 hover:text-white transition-colors">Fußballcamps</a></div>
                <div><a href="#services" className="text-white/80 hover:text-white transition-colors">Mädchenfußball</a></div>
                <div><a href="#services" className="text-white/80 hover:text-white transition-colors">Athletiktraining</a></div>
              </div>
            </div>

            <div className="space-y-6">
              <h4 className="text-lg font-bold">Navigation</h4>
              <div className="space-y-3">
                <div><a href="#home" className="text-white/80 hover:text-white transition-colors">Home</a></div>
                <div><a href="#about" className="text-white/80 hover:text-white transition-colors">Über uns</a></div>
                <div><a href="#services" className="text-white/80 hover:text-white transition-colors">Programme</a></div>
                <div><a href="#trainers" className="text-white/80 hover:text-white transition-colors">Unser Team</a></div>
                <div><a href="#testimonials" className="text-white/80 hover:text-white transition-colors">Testimonials</a></div>
                <div><a href="#contact" className="text-white/80 hover:text-white transition-colors">Kontakt</a></div>
              </div>
            </div>

            <div className="space-y-6">
              <h4 className="text-lg font-bold">Kontakt</h4>
              <div className="space-y-3 text-white/80">
                <div>
                  <p className="font-medium text-white">Trainingszentrum</p>
                  <p>Sportpark Elite<br />Stadionstraße 45<br />80331 München</p>
                </div>
                <div>
                  <p className="font-medium text-white">Kontakt</p>
                  <p>strikerzone@icloude.com<br />+49 176 61803510</p>
                </div>
                <div>
                  <p className="font-medium text-white">Trainingszeiten</p>
                  <p>Mo-Fr: 15:00-20:00 Uhr<br />Sa-So: 9:00-17:00 Uhr</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Bottom Bar */}
        <div className="py-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-white/80">
              © 2024 Striker Zone Academy. Alle Rechte vorbehalten.
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-white/80 hover:text-white transition-colors">Impressum</a>
              <a href="#" className="text-white/80 hover:text-white transition-colors">Datenschutz</a>
              <a href="#" className="text-white/80 hover:text-white transition-colors">AGB</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}